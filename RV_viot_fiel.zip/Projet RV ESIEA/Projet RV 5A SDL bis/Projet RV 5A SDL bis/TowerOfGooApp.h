#pragma once
#include <vector>
#include "EventC.h"
#include "Scene.h"
#include "TCPConnection.h"

#include "Tracker.h"

#define UseMasterServer true
#define tabSize 17



class EventC;
class Scene;

class TowerOfGooApp
{
public:
	TowerOfGooApp(void);
	~TowerOfGooApp(void);
	bool hasToKeepRunning();
	void pushEvent(EventC arg);
	void sendQuitSignal();
	void run();
	Scene* getScene();
	void initOpenGL();

	float xMove;
	float yMove;
	float zMove;

private:
	CTCPConnection masterServer;
	bool keepRunning;
	bool isSceneLocked;
	bool isSwapLocked;
	std::vector<EventC> EventStack;
	Scene* scene;
	int TimeOfPreviousSceneUpdate;
	int betweenFrameTime;

protected:
	static BOOL initialized;
};
