#include "PhysicModel.h"


PhysicModel::PhysicModel(void)
{
	friction= 0.95f;
	springConstant=1000;
	affectedByGravity=true;
	mass=10;
	alpha=20.0f;
}

PhysicModel::~PhysicModel(void)
{
}

void PhysicModel::update(float step)
{
	Vector3D acceleration = computeAcceleration();
	this->computePhysic(acceleration,step);
}

void PhysicModel::computePhysic(Vector3D acceleration,float step)
{
	nextVelocity=velocity+acceleration*step;
	nextPosition=position+velocity*step;
	nextVelocity*=friction;
}

void PhysicModel::updateValue()
{
	this->position=this->nextPosition;
	this->velocity=this->nextVelocity;
	float y = this->position.m_y;

	if (y<-0.0001f)
	{
		this->position.m_y=0.0f;
		this->velocity.m_y*=-0.6f;
	}

	float xp = this->position.m_x - this->objectLinkedWith->getWorldTransform().getNumber(0,3);
	float yp = this->position.m_y - this->objectLinkedWith->getWorldTransform().getNumber(1,3);
	float zp = this->position.m_z - this->objectLinkedWith->getWorldTransform().getNumber(2,3);

	this->objectLinkedWith->setLocalMatrix(Matrix4x4::Multiply(this->objectLinkedWith->getTransform(),Matrix4x4::TranslationMatrix(xp,yp,zp)));
}

Vector3D PhysicModel::computeAcceleration()
{
	Vector3D sumOfForces(0.0f,0.0f,0.0f);

	for (unsigned int i=0;i<this->neighbors.size();i++)
	{
		Vector3D temp = ComputeForceAppliedBy(i);
		sumOfForces=sumOfForces+temp;
	}

	// Force g�n�r�e par la gravit�
	if(this->affectedByGravity)
		sumOfForces.m_y-=this->mass*9.8f;

	float invertOfMass = 1/mass;
	Vector3D acceleration = sumOfForces * invertOfMass;
	return acceleration;
}

Vector3D PhysicModel::ComputeForceAppliedBy(int index)
{
	PhysicModel* neighbor =  this->neighbors[index];
	Vector3D thisToNeighbor=neighbor->position - this->position;																																			
	float ForceValue=this->springConstant *(thisToNeighbor.GetNorm() - this->neighborsOriginalDistance[index]);
	Vector3D forceDirection = thisToNeighbor;
	forceDirection.Normalize();
	Vector3D force = forceDirection * ForceValue;

	//Frottements												
	Vector3D frict=forceDirection*((this->velocity - neighbor->velocity).DotProduct(forceDirection))*alpha;

	if (force.DotProduct(frict)>0)																			
		force-=frict;																						

	return force;
}

Vector3D PhysicModel::getPosition()
{
	return this->position;
}

void PhysicModel::bind(Object3D* objectToLinkWith)
{
	this->objectLinkedWith=objectToLinkWith;
}

void PhysicModel::addNeighbor(PhysicModel* neighbor, float distance)
{
	this->neighbors.push_back(neighbor);
	this->neighborsOriginalDistance.push_back(distance);
}

void PhysicModel::setPosition(float x, float y, float z)
{
	this->position.m_x=x;
	this->position.m_y=y;
	this->position.m_z=z;
}