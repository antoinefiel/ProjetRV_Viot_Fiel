#include "Object3D.h"


Object3D::Object3D(void)
{
	this->parent=NULL;
	this->localMatrix = Matrix4x4::Identity();
}

Object3D::Object3D(Object3D* parentArg)
{
	this->parent=parentArg;
}

Object3D::~Object3D(void)
{
}

std::vector<Object3D*> Object3D::getChilds()
{
	return this->childs;
}

void Object3D::addChild(Object3D* childToAdd)
{
	this->childs.push_back(childToAdd);
	childToAdd->parent=this;
}

Object3D* Object3D::getParent()
{
	if(this->parent == NULL)
	{
		throw "Object has no parent !";
		return NULL;
	}
	else
	{
		return this->parent;
	}
}

Matrix4x4 Object3D::getWorldTransform()
{
	if(this->hasParent())
	{
		Matrix4x4 currentMatrix = this->localMatrix;
		Matrix4x4 matrix = Matrix4x4::Multiply(this->getParent()->getWorldTransform(),currentMatrix);
		return matrix;
	}
	else
	{
		return this->localMatrix;
	} 
}

Matrix4x4 Object3D::getTransform()
{
	return this->localMatrix;
}

bool Object3D::hasParent()
{
	if(this->parent == NULL)
	{
		return false;
	}
	else
	{
		return true;
	}
}

void Object3D::setLocalMatrix(Matrix4x4 arg)
{
	for (int i =0;i<4;i++)
	{
		for (int j =0;j<4;j++)
		{
			this->localMatrix.setNumber(i,j,arg.getNumber(i,j));
		}
	}
}