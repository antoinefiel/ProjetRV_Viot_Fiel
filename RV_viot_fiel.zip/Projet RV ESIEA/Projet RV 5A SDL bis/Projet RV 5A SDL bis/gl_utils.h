#ifndef _GL_UTILS_
#define _GL_UTILS_

#include "./glew-1.7.0/include/GL/glew.h"
#include <Windows.h>
#include <string>
#include <vector>

using namespace std;

// Canal number to store the textures
#define NB_CHANNELS 13

// To offset from the start (@ 0) of 'i' bytes 
#define OFFSET(i) ((char *)NULL + (i))

// To draw the referential 
BOOL drawRef(float coef, BOOL refCenter = FALSE , float size=0.0f);
// To draw the grid 
BOOL drawGrid(float size, int nbLines);
// To draw the cube
BOOL drawCube(float size, GLuint textid);
//
//BOOL LoadAndGenTexture(const string &texturePath, GLuint &outID);

// To store the OpenGL ID of the texture and its path 
struct Texture 
{
	string mTexturePath;
	GLuint mGlID;
};

// To bind the ID of the textures for the material
// It can also store the shader ID to use for this material
struct MaterialAdapter
{
	// handle gl texture for each channel
	GLuint mTexturesID[NB_CHANNELS];
	GLint shaderID;
};

//-----------------------------------------------
//
// structure utile pour les VBOs. 
// NB le pragma assure d'avoir un bloc memoire contigu 
// (sinon le compilo pourrait se permettre de faire des optimisations en alignant sur 
// des multiples de 4(32bits) ou de 8(64bits) en memoire)

// VertexData structure to prepare vertex for VBO
// nb : padding is for ATI board that need 32 byte aligned data
// should be skipped for nvidia GPU
// btw this should improve a bit transfert performance 
// see : http://www.opengl.org/wiki/Vertex_Buffer_Object



#pragma pack(push, 1)

struct VEC2{
	float u,v;
};

struct VEC3 {
	float x,y,z;
};

struct VEC4 {
	float x,y,z,w;
};

struct VertexData
{											//	storage size  | total
	VEC3 position;		// Vertex				3x4 octets	  | 12 
	VEC3 normal;		// Normal				3x4 octets	  | 24	
	VEC3 tangent;		// tangent				3x4 octets	  | 36
	VEC3 bitangent;		// binormal				3x4 octets	  | 48
	VEC4 color;			// color				4*4 octets	  | 64
	VEC2 uv[NB_CHANNELS]; // UVs				2*4*13 octets | 168
	// Add pad for ATI board if struct is modified
};

#pragma pack(pop)

// To store the vbo IDs (vertex buffer array & faces buffer to draw the elements)
struct VBO {
	GLuint vId; // vertex Buffer ID
	GLuint fId; // faces Buffer ID (contains 3 vertex index per face, index from the vID buffer)
  GLuint vaId;
};


#endif