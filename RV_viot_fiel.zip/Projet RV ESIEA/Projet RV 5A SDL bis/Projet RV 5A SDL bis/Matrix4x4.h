#pragma once
class Matrix4x4
{
public:
	Matrix4x4(void);
	~Matrix4x4(void);
	static Matrix4x4 Multiply(Matrix4x4 A, Matrix4x4 B);
	static Matrix4x4 TranslationMatrix(float x,float y, float z);
	static Matrix4x4 Identity();
	void Transpose();
	float getNumber(int rowIndex, int columnIndex);
	void setNumber(int rowIndex, int columnIndex , float value);
	float* convertToMatrixTable();
private:
	float localMatrix[4][4];
};

