#include "PhysicSolver.h"
#include "Vector3D.h"


PhysicSolver::PhysicSolver(void)
{
	maximalDistanceToLinkSphere = 2;
	minimalNumberOfSphereToLinkWith = 0;
	step = 0.01f;
	cumulatedTime=0;
}


PhysicSolver::~PhysicSolver(void)
{
}

void PhysicSolver::run(float remainingTime)
{
	cumulatedTime=cumulatedTime+remainingTime;
	while (cumulatedTime>=step)
	{
		for (unsigned int i=0;i<this->PhysicEntities.size();i++)
		{
				this->PhysicEntities[i]->update(step);
		}
		for (unsigned int i=0;i<this->PhysicEntities.size();i++)
		{
				this->PhysicEntities[i]->updateValue();
		}
		cumulatedTime-=step;
	}
}

bool PhysicSolver::canInsertSphereAtLocation(Vector3D positionOfNewSphere)
{
	int numberOfSphereInRadius = 0;
	for (unsigned int i=0;i<this->PhysicEntities.size();i++)
	{
		Vector3D currentEntityToNewSphere = this->PhysicEntities[i]->getPosition() - positionOfNewSphere;
		float distance = currentEntityToNewSphere.GetNorm();
		if (distance <= this->maximalDistanceToLinkSphere)
		{
			numberOfSphereInRadius++;
		}
	}
	if (numberOfSphereInRadius >= this->minimalNumberOfSphereToLinkWith)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void PhysicSolver::insertEntity(PhysicModel* entity, Vector3D location)
{
	this->PhysicEntities.push_back(entity);
	for (unsigned int i=0;i<this->PhysicEntities.size()-1;i++)
	{
		Vector3D currentEntityToNewSphere = this->PhysicEntities[i]->getPosition() - location;
		float distance = currentEntityToNewSphere.GetNorm();
		if (distance <= this->maximalDistanceToLinkSphere)
		{
			this->PhysicEntities[i]->addNeighbor(entity,distance);
			entity->addNeighbor(this->PhysicEntities[i],distance);
		}
	}
}
