#define _USE_MATH_DEFINES
#include <cmath>

#include "glew-1.7.0\include\GL\glew.h"
#include <Windows.h>
#include "./SDL/include/SDL.h"

#include <gl/glu.h>

#include "Scene.h"
#include "Dummy3DObject.h"
#include "RightHandedAxisRef.h"
#include "Object3D.h"
#include "CreateSphereTracker.h"

#include "GooSphere.h"
#include "PhysicModel.h"
#include "GroundPlane.h"

#include <gl/gl.h>
#include <GL/GL.h>

double COEFF = 3;


Scene::Scene(void)
{
	this->root = new Dummy3DObject();
	frameConter = 0;
	this->physicSolver = new PhysicSolver();	// TODO remove when done
	this->populate();
}

Scene::~Scene(void)
{
}

Object3D* Scene::getRoot()
{
	return this->root;
}

void Scene::populate()
{
	//TODO
	this->xTrackerMove=0;
	this->yTrackerMove=0;
	this->zTrackerMove=0;
	GroundPlane* ground = new GroundPlane();
	Camera* camera = new Camera();
	RightHandedAxisRef* ref = new RightHandedAxisRef();
	CreateSphereTracker* createSphereTrackerScene = new CreateSphereTracker();
	this->createSphereTracker = createSphereTrackerScene;
	this->getRoot()->addChild(createSphereTrackerScene);
	this->getRoot()->addChild(ground);
	this->getRoot()->addChild(ref);
	this->getRoot()->addChild(camera);
	this->activeCamera=camera;
	camera->setLocalMatrix(Matrix4x4::Multiply(camera->getTransform(),Matrix4x4::TranslationMatrix(0,0,-2)));
	createSphereTracker->setLocalMatrix(Matrix4x4::Multiply(createSphereTracker->getTransform(),Matrix4x4::TranslationMatrix(0.00001f,0,0)));
}

void Scene::doSwapLocking()
{
	SDL_GL_SwapBuffers();
}

Camera* Scene::getActiveCamera()
{
	if(this->activeCamera == NULL)
	{
		throw "No active camera in scene !";
		return NULL;
	}
	else
	{
		return this->activeCamera;
	}
}

void Scene::computeNextFrame(float timeEllapsedSincePreviousFrameArg)
{
	this->timeEllapsedSincePreviousFrame=timeEllapsedSincePreviousFrameArg;
	this->frameConter++;
	this->clearOpenGL();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//TODO
	// compute physics to implement
	this->physicSolver->run(timeEllapsedSincePreviousFrameArg);

	this->recursiveThink(this->getRoot());
	this->recursiveUpdate(this->getRoot());
	this->updateCreateSphereTrackerPosition();
	Camera* activeCamera = this->getActiveCamera();
	this->moveWorldToMatchCamera(activeCamera);
	

	int eye;

	///if(this->frameConter%2==0){
	for (int i=0; i < (2!=0?2:1) ; i++){

		eye = i*2-1;	
		if(i==0)  glDrawBuffer(GL_BACK_LEFT);
		else      glDrawBuffer(GL_BACK_RIGHT);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		this->recursiveDraw(this->getRoot());
		activeCamera->doProjection(eye);
	}
	//}

	/*else{
	for (int i=0; i < (2!=0?2:1) ; i++){

		eye = i*2-1;	
		if(i==0)  glDrawBuffer(GL_BACK_RIGHT);
		else      glDrawBuffer(GL_BACK_LEFT);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		this->recursiveDraw(this->getRoot());
		activeCamera->doProjection(-1*eye);
	}
	}*/

	activeCamera->doProjection(eye);

}

void Scene::recursiveDraw(Object3D* element)
{
	glPushMatrix();

	Matrix4x4 elementTransform =  element->getTransform();
	elementTransform.Transpose();
	glMultMatrixf(elementTransform.convertToMatrixTable());
	if(element->isGeometry())
	{
		element->draw();
	}
	std::vector<Object3D*> childs = element->getChilds();
	for (unsigned int i=0;i<childs.size();i++)
	{
		this->recursiveDraw(childs[i]);
	}
	glPopMatrix();
}

void Scene::clearOpenGL()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(1, 1, 1, 0);
	glClearDepth(1.0f);
	int screen_width = SDL_GetVideoSurface()->w; 
	int screen_height = SDL_GetVideoSurface()->h;
	glViewport(0, 0, screen_width, screen_height);
}

void Scene::moveWorldToMatchCamera(Camera* arg)
{
	
	Matrix4x4 worldTransformActiveCamera = activeCamera->getWorldTransform();
	worldTransformActiveCamera.Transpose();
	float* matrixTable = worldTransformActiveCamera.convertToMatrixTable();
	glMultMatrixf(matrixTable);
	
	
	//
	//glLoadIdentity();
	//glTranslated(0,-2.0f,-9.0f);
	//glRotated(30,0,1,0);

	//glTranslatef(2,0,0);
	//glRotated(0.1f,0,1,0);

}

void Scene::setApp(TowerOfGooApp* arg)
{
	this->app = arg;
}

void Scene::sendMoveTracker(float x, float y,float z)
{
	this->xTrackerMove=COEFF *x;
	this->yTrackerMove=COEFF *y;
	this->zTrackerMove=COEFF *z;
}

void Scene::updateCreateSphereTrackerPosition()
{
	Matrix4x4 trackerTransform = this->createSphereTracker->getTransform();
	Matrix4x4 trackerTranslationMatrix = Matrix4x4::TranslationMatrix(xTrackerMove,yTrackerMove,zTrackerMove);
	Matrix4x4 newTransform = Matrix4x4::Multiply(Matrix4x4::Identity(),trackerTranslationMatrix);
	this->createSphereTracker->setLocalMatrix(newTransform);
}

void Scene::recursiveThink(Object3D* element)
{
	element->think(this->timeEllapsedSincePreviousFrame);
	std::vector<Object3D*> childs = element->getChilds();
	for (unsigned int i=0;i<childs.size();i++)
	{
		this->recursiveThink(childs[i]);
	}
}

void Scene::recursiveUpdate(Object3D* element)
{
	element->update();
	std::vector<Object3D*> childs = element->getChilds();
	for (unsigned int i=0;i<childs.size();i++)
	{
		this->recursiveUpdate(childs[i]);
	}
}

void Scene::insertSphere()
{
	float x = this->createSphereTracker->getWorldTransform().getNumber(0,3);
	float y = this->createSphereTracker->getWorldTransform().getNumber(1,3);
	float z = this->createSphereTracker->getWorldTransform().getNumber(2,3);

	Vector3D positionOfNewSphere = Vector3D(x,y,z);

	if(this->physicSolver->canInsertSphereAtLocation(positionOfNewSphere))
	{
		GooSphere* sphere = new GooSphere();
		PhysicModel* model = new PhysicModel();
		model->bind(sphere);
		model->setPosition(x,y,z);
		Matrix4x4 newTransformMatrix = Matrix4x4::Multiply(sphere->getTransform(), Matrix4x4::TranslationMatrix(x,y,z));
		sphere->setLocalMatrix(newTransformMatrix);

		this->physicSolver->insertEntity(model,positionOfNewSphere);
		this->getRoot()->addChild(sphere);

	}
}