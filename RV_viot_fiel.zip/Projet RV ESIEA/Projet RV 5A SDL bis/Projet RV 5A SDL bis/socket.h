/*
   Copyright (C) 2001 Nate Miller nathanm@uci.edu

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

   See gpl.txt for more information regarding the GNU General Public License.
*/
/*
   WORKLOG

   TODO  
      * change canread and canwrite into a single method which returns a
        bitmask of the states for the socket?
      * need a way to test multiple sockets for read/write.  write another
        class?
*/
#ifndef __SOCKETH__
#define __SOCKETH__

#include "netAddress.h"

struct socket_t
{
   socket_t()                     {sock = INVALID_SOCKET;}
   virtual ~socket_t()            { }

   bool IsValidSocket(void)       {return sock != INVALID_SOCKET;}
   netAddress_t *GetAddress(void) {return &addr;}

   void Set(socket_t &s);

   void Close(void);   
   bool CanRead(void);
   bool CanWrite(void);
      
   virtual int Send(const void *buffer, int len) = 0;
   virtual int SendAll(const void *buffer, int len);
   virtual int Read(void *dest, const int &len) = 0;
   
protected:
   // throws error_t
   virtual void SetAddress(const char *host, unsigned short port); 
   // throws error_t
   virtual void CreateSocket(void) = 0;

   SOCKET sock;
   netAddress_t addr;
};

#endif