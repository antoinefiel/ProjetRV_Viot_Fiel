#define _USE_MATH_DEFINES
#include <cmath>
#include "GooSphere.h"
#include <Windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <GL/GL.h>


GooSphere::GooSphere(void)
{
}


GooSphere::~GooSphere(void)
{
}

bool GooSphere::isGeometry()
{
	return true;
}

void GooSphere::draw()
{
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);

	// Modiy the attribs
	glEnable(GL_COLOR_MATERIAL);
	//glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glLineWidth(3.0f);

	glColor4f(0.5f,0.5f,0.5f,1.0f);

	int i, j;
	int lats = 32;
	int longs = 32;
	float scaleFactor = 0.05f;
	for(i = 0; i <= lats; i++) {
		double lat0 = M_PI * (-0.5 + (double) (i - 1) / lats);
		double z0  = sin(lat0);
		double zr0 =  cos(lat0);

		double lat1 = M_PI * (-0.5 + (double) i / lats);
		double z1 = sin(lat1);
		double zr1 = cos(lat1);

		glBegin(GL_QUAD_STRIP);
		for(j = 0; j <= longs; j++) {
			double lng = 2 * M_PI * (double) (j - 1) / longs;
			double x = cos(lng);
			double y = sin(lng);

			glNormal3f(x * zr0 * scaleFactor, y * zr0 * scaleFactor, z0 * scaleFactor);
			glVertex3f(x * zr0 * scaleFactor, y * zr0 * scaleFactor, z0 * scaleFactor);
			glNormal3f(x * zr1 * scaleFactor, y * zr1 * scaleFactor, z1 * scaleFactor);
			glVertex3f(x * zr1 * scaleFactor, y * zr1 * scaleFactor, z1 * scaleFactor);
		}
		glEnd();
	}
	// Restore the attribs
	glPopAttrib();
	// restore the transformation matrix 
	glPopMatrix();
}