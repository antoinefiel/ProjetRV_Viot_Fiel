#pragma once

#include "Vector3D.h"
#include "Object3D.h"
#include "Vector3D.h"
#include <vector>

class PhysicModel
{
public:
	PhysicModel(void);
	~PhysicModel(void);
	void update(float step);
	void updateValue();
	Vector3D getPosition();
	void bind(Object3D* objectToLinkWith);
	void addNeighbor(PhysicModel * neighbor, float distance);
	void setPosition(float x, float y, float z);
private:
	Object3D* objectLinkedWith;
	Vector3D computeAcceleration();
	
	Vector3D ComputeForceAppliedBy(int index);
	void computePhysic(Vector3D acceleration, float step);

	Vector3D position;
	Vector3D nextPosition;
	Vector3D velocity;
	Vector3D nextVelocity;

	std::vector<PhysicModel*> neighbors;
	std::vector<float> neighborsOriginalDistance;

	float friction;
	float mass;
	float springConstant;
	float alpha;	
	bool affectedByGravity;

};

