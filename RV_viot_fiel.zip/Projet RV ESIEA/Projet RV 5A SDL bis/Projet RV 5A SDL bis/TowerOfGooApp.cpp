#include "glew-1.7.0\include\GL\glew.h"
#include <Windows.h>
#include <gl/glu.h>
#include "TowerOfGooApp.h"
#include <GL/GL.h>
#include <gl/gl.h>

BOOL	TowerOfGooApp::initialized = FALSE;

TowerOfGooApp::TowerOfGooApp(void)
{
	this->keepRunning=true;
	this->scene = new Scene();
	this->scene->setApp(this);
	//TODO remove when done
	this->isSceneLocked=false;
	this->isSwapLocked=false;
	this->TimeOfPreviousSceneUpdate=0;
	this->initOpenGL();
	
	if(UseMasterServer)
	{
		masterServer.Init("localhost",(unsigned short)5000);
		int SwapDoneConstant = 2;
		masterServer.SendData((void *)&SwapDoneConstant,sizeof(int));
		this->isSceneLocked=true;
		this->isSwapLocked=true;
	}
	else
	{
		this->isSceneLocked=false;
		this->isSwapLocked=true;
	}

}

TowerOfGooApp::~TowerOfGooApp(void)
{
}

bool TowerOfGooApp::hasToKeepRunning()
{
	return this->keepRunning;
}

void TowerOfGooApp::pushEvent(EventC arg)
{
	this->EventStack.push_back(arg);
}

void TowerOfGooApp::sendQuitSignal()
{
	this->keepRunning=false;
}


void TowerOfGooApp::run()
{
	if (UseMasterServer)
	{
		float DataIn[tabSize];
		for(int i = 0 ; i <tabSize; i++)
		{
			DataIn[i]=0;
		}
		bool keepReadingDataFromServer=true;
		// TODO get time to compute physic 
		while(masterServer.DataWaiting() && keepReadingDataFromServer)
		{
			masterServer.ReadData((void*)&DataIn, tabSize*sizeof(float));
			if(DataIn[0]==1) // order to compute Scene
			{
				this->isSceneLocked=false;
				keepReadingDataFromServer=false;
				this->betweenFrameTime =  DataIn[1];
				this->scene->sendMoveTracker(DataIn[2],DataIn[3],DataIn[4]);
				Matrix4x4 mat = Matrix4x4::Multiply(Matrix4x4::Identity(), Matrix4x4::TranslationMatrix(-DataIn[9],-DataIn[10],-DataIn[11]));
				this->scene->getActiveCamera()->setLocalMatrix(mat);

				if(DataIn[16]!= 0)
				{
					this->scene->insertSphere();
				}
			}

			if(DataIn[0]==2) // order to compute Scene
			{
				printf("le serveur me demande de swapper\n");
				this->isSwapLocked=false;
				keepReadingDataFromServer=false;
			}
		}
	}
	else
	{
		this->scene->sendMoveTracker(xMove,yMove,zMove);
		int currentTime = SDL_GetTicks();
		betweenFrameTime = currentTime - this->TimeOfPreviousSceneUpdate;
		this->TimeOfPreviousSceneUpdate = currentTime; 
	}

	for(unsigned int i=0;i<this->EventStack.size();i++)
	{
		EventC EventToProcess = this->EventStack[0];
		EventToProcess.process(this);
		this->EventStack.erase(this->EventStack.begin());
	}
	if(!this->isSceneLocked)
	{
		int currentTime = SDL_GetTicks();
		int betweenFrameTime = currentTime-this->TimeOfPreviousSceneUpdate;
		float betweenFrameTimeInSeconds = (float) (((float) betweenFrameTime) / 1000.0f);
		this->scene->computeNextFrame(betweenFrameTimeInSeconds);
		this->TimeOfPreviousSceneUpdate=currentTime;

		if (UseMasterServer)
		{
			int SwapReadyConstant = 1;
			this->isSceneLocked=true;
			masterServer.SendData((void *)&SwapReadyConstant,sizeof(int));
		}
		else
		{
			this->isSceneLocked=true;
			this->isSwapLocked=false;
		}

		// TODO
		//this->masterServer.sendMsg(TowerOfGooApp::FrameComputed);
		//this->isSceneLocked=true;
	}
	if(!this->isSwapLocked)
	{
		this->scene->doSwapLocking();

		if (UseMasterServer)
		{
			int SwapDoneConstant = 2;
			this->isSwapLocked=true;
			masterServer.SendData((void *)&SwapDoneConstant,sizeof(int));
		}
		else
		{
			this->isSceneLocked=false;
			this->isSwapLocked=true;
		}
		// TODO
		//this->masterSever.sendMsg(TowerOfGooApp::SceneSwapped);
		//this->isSwapLocked=true;
	}

}

Scene* TowerOfGooApp::getScene()
{
	return this->scene;
}

void TowerOfGooApp::initOpenGL()
{
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	int numLight = GL_LIGHT0+0;
	GLfloat lightPosition[4];

	lightPosition[0]=1;
	lightPosition[1]=1;
	lightPosition[2]=1;
	lightPosition[3]=1;

	glLightfv(numLight,GL_POSITION,lightPosition);
}