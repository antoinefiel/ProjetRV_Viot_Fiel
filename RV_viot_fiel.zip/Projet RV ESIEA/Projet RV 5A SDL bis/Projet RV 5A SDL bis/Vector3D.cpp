#include "Vector3D.h"


#include <cmath>

Vector3D::Vector3D(void)
{
	m_x=0.0f;
	m_y=0.0f;
	m_z=0.0f;
}

Vector3D::Vector3D(float a, float b, float c)
{
	m_x=a;
	m_y=b;
	m_z=c;
}

Vector3D::~Vector3D(void)
{
}

void Vector3D::Set(float a, float b, float c)
{
	m_x=a;
	m_y=b;
	m_z=c;
}

float Vector3D::GetNorm()
{
	return (sqrt(m_x*m_x + m_y*m_y + m_z*m_z));
}

Vector3D Vector3D::CrossProduct(Vector3D v)
{
	Vector3D out;
	out.m_x = m_y*v.m_z - m_z*v.m_y;
	out.m_y = m_z*v.m_x - m_x*v.m_z;
	out.m_z = m_x*v.m_y - m_y*v.m_x;
	return out;
}

float Vector3D::DotProduct(Vector3D v)
{
	return (m_x*v.m_x + m_y*v.m_y + m_z*v.m_z);
}

void Vector3D::Normalize()
{

	float norme = sqrt(m_x*m_x + m_y*m_y + m_z*m_z);
	if(norme!=0.0f)
	{
		m_x/=norme;
		m_y/=norme;
		m_z/=norme;
	}
	else
	{
		m_x=0.0f;
		m_y=0.0f;
		m_z=0.0f;
	}
}

Vector3D Vector3D::operator + (Vector3D v)
{
	Vector3D res(m_x+v.m_x,m_y+v.m_y,m_z+v.m_z);
	return res;
}

Vector3D Vector3D::operator - (Vector3D v)
{
	Vector3D res(m_x-v.m_x,m_y-v.m_y,m_z-v.m_z);
	return res;
}

Vector3D Vector3D::operator * (float a)
{
	Vector3D res(a*m_x,a*m_y,a*m_z);
	return res;
}

Vector3D Vector3D::operator / (float a)
{
	Vector3D res(m_x/a,m_y/a,m_z/a);
	return res;
}

void Vector3D::operator += (Vector3D v)
{
	m_x+=v.m_x;
	m_y+=v.m_y;
	m_z+=v.m_z;
}

void Vector3D::operator -= (Vector3D v)
{
	m_x-=v.m_x;
	m_y-=v.m_y;
	m_z-=v.m_z;
}

void Vector3D::operator *= (float a)
{
	m_x*=a;
	m_y*=a;
	m_z*=a;
}

