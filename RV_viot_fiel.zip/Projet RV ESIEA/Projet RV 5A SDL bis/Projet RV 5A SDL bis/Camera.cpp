#define _USE_MATH_DEFINES
#include <cmath>
#include <Windows.h>
#include "./SDL/include/SDL.h"

#include <gl/glu.h>
#include <GL/GL.h>
#include <gl/gl.h>

#include "Camera.h"


Camera::Camera(void)
{
}


Camera::~Camera(void)
{
}

bool Camera::isCamera()
{
	return true;
}

void Camera::think(float timeEllapsedSincePreviousFrame)
{
	return;
}

bool Camera::isLight()
{
	return false;
}

bool Camera::isGeometry()
{
	return false;
}

void Camera::draw()
{
	return;
}

void Camera::doProjection(int eyeChoice)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	int screen_width = SDL_GetVideoSurface()->w; // this gives surface width 
	int screen_height = SDL_GetVideoSurface()->h; // this gives surface height

	GLdouble fovY=45;
	GLdouble fW, fH;
	GLdouble zNear = 0.001;
	GLdouble zFar = 100;
	GLdouble IPD_2 = 0.0325;
	fH = tan( fovY / 360 * M_PI ) * zNear;
	GLdouble aspect = (double) ((double) screen_width/(double) screen_height);
	fW = fH * aspect;
	//glFrustum( -fW, fW, -fH, fH, zNear, zFar );

	GLdouble left, right;
     
   /* left = (-0.15*aspect)+eyeChoice*IPD_2;
    right = (0.15*aspect)+eyeChoice*IPD_2;
    glFrustum(
		left*zNear/0.5,
		right*zNear/0.5,
		-zNear*0.15/0.5,
		zNear*0.15/0.5, 
		zNear,
		zFar
		);
   glTranslated(eyeChoice*IPD_2,0,0); */

	//
	//GLdouble left, right;
	GLdouble top, bot;

	//

	GLdouble cameraX, cameraY, cameraZ;

	//

	Matrix4x4 mat = this->getWorldTransform();
	
	cameraX = -mat.getNumber(0,3);
	cameraY = -mat.getNumber(1,3);;
	cameraZ = -mat.getNumber(2,3);;

	
	//Ecran du bas

	/*
	left = (-(double)screen_width/2-cameraX)*zNear/cameraY;
	right = ((double)screen_width/2-cameraX)*zNear/cameraY;
	
	top = ((double)screen_height-cameraZ)*zNear/cameraY;
	bot = (-cameraZ)*zNear/cameraY;

	glFrustum( left, right, bot, top, zNear, zFar );

	glRotated(90,0,0,1);
	*/

	//Ecran du haut

	//left = (-(double)screen_width/2-cameraX)*zNear/(-cameraZ);
	//right = ((double)screen_width/2-cameraX)*zNear/(-cameraZ);

	//top = ((double)screen_height-cameraY)*zNear/(-cameraZ);
	////bot = (-cameraY)*zNear/(-cameraZ);
	//bot = ((double)screen_height-cameraZ)*zNear/cameraY;

	//glFrustum( left, right, bot, top, zNear, zFar );

	float coeff = zNear/(0.5625-cameraZ);
	static float tab[128] = {coeff,zNear,cameraX,cameraY,cameraZ};
	tab[0] = coeff;
	tab[1] = zNear;
	tab[2] = cameraX;
	tab[3] = cameraY;
	tab[4] = cameraZ;

	glFrustum(coeff*(-0.5 - cameraX), coeff*(0.5 - cameraX), coeff*(-cameraY), coeff*(0.5625 - cameraY), zNear, zFar);

//	glMatrixMode(GL_MODELVIEW);
//	glTranslated(-cameraX, -cameraY, /*-1.65 +*/ cameraZ);
}

void Camera::update()
{
	return;
}