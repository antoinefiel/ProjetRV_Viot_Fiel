#pragma once
#include <vector>
#include "Matrix4x4.h"
class Object3D
{
public:
	Object3D(void);
	Object3D(Object3D* parentArg);
	~Object3D(void);

	virtual void think(float timeEllapsedSincePreviousFrame) = 0;
	virtual void update() = 0;
	virtual bool isLight() = 0;
	virtual bool isCamera() = 0;
	virtual bool isGeometry() = 0;
	virtual void draw()=0;
	Object3D* getParent();
	bool hasParent();
	Matrix4x4 getWorldTransform();
	Matrix4x4 Object3D::getTransform();
	void setLocalMatrix(Matrix4x4 arg);
	std::vector<Object3D*> getChilds();
	void Object3D::addChild(Object3D* childToAdd);
	
private:
	Object3D* parent;
	Matrix4x4 localMatrix;
	std::vector<Object3D*> childs;
};

