#pragma once

#include "./vrpn/includes/vrpn_Tracker.h"
#include "./gl_utils.h"
#include <cmath>

using namespace std;

#define defaultGlassesServer "head@192.168.2.230:3884"
#define defaultHandServer "hand@192.168.2.230:3884"
#define defaultButtonServer "xl0@192.168.2.230:3884"
#define interpolationCoef 0.2 //between 0 and 1

class Tracker
{
	public:
		Tracker(std::string);
		~Tracker();
		void trackingLoop();
		void getTransform(double* mat);

	//private:
		void lerp(double* final, double* start, double* end, double coef);
		
		vrpn_Tracker_Remote* vrpnTracker;
		vrpn_float64 buffer[7];
		vrpn_float64 *clientPosition, *clientRotation, *clientNewPosition, *clientNewRotation;
};