#include "Matrix4x4.h"


Matrix4x4::Matrix4x4(void)
{
}


Matrix4x4::~Matrix4x4(void)
{
}

float Matrix4x4::getNumber(int rowIndex, int columnIndex)
{
	bool firstAssertion = rowIndex >=0 && rowIndex<=3;
	bool secondAssertion = columnIndex >=0 && columnIndex<=3;

	if(firstAssertion && secondAssertion)
	{
		return this->localMatrix[rowIndex][columnIndex];
	}
	else
	{
		throw "row index and/or column index does not fit in the matrix!";
	}
}

void Matrix4x4::setNumber(int rowIndex, int columnIndex , float value)
{
	bool firstAssertion = rowIndex >=0 && rowIndex<=3;
	bool secondAssertion = columnIndex >=0 && columnIndex<=3;

	if(firstAssertion && secondAssertion)
	{
		this->localMatrix[rowIndex][columnIndex]=value;
	}
	else
	{
		throw "row index and/or column index does not fit in the matrix!";
	}
}

Matrix4x4 Matrix4x4::Identity()
{
	Matrix4x4 returnMatrix;
	for (int i=0; i<4; i++) 
	{
		for (int j=0; j<4; j++) 
		{
			if(i==j)
			{
				returnMatrix.setNumber(i,j,1);
			}
			else 
			{
				returnMatrix.setNumber(i,j,0);
			}
		}
	}
	return returnMatrix;
}

Matrix4x4 Matrix4x4::Multiply(Matrix4x4 A, Matrix4x4 B)
{
	Matrix4x4 returnMatrix;
	for (int i=0; i<4; i++) 
	{
		for (int j=0; j<4; j++) 
		{
			float temp=0;
			for (int k=0; k<4; k++) 
			{
				float Anumber = A.getNumber(i,k);
				float Bnumber = B.getNumber(k,j);
				temp= temp + Anumber * Bnumber;
			}
			returnMatrix.setNumber(i,j,temp);
		}
	}
	return returnMatrix;
}

float* Matrix4x4::convertToMatrixTable()
{
	float* matrixValue = new float[16];
	for (int i=0; i<4; i++) 
	{
		for (int j=0; j<4; j++) 
		{
			matrixValue[4*i+j]=this->getNumber(i,j);
		}
	}
	return matrixValue;
}

Matrix4x4 Matrix4x4::TranslationMatrix(float x,float y, float z)
{
	Matrix4x4 returnMatrix=Matrix4x4::Identity();
	returnMatrix.setNumber(0,3,x);
	returnMatrix.setNumber(1,3,y);
	returnMatrix.setNumber(2,3,z);
	return returnMatrix;
}

void Matrix4x4::Transpose()
{
	Matrix4x4 temp;
	for (int i=0; i<4; i++) 
	{
		for (int j=0; j<4; j++) 
		{
			temp.setNumber(i,j,this->getNumber(i,j));
		}
	}
	for (int i=0; i<4; i++) 
	{
		for (int j=0; j<4; j++) 
		{
			this->setNumber(i,j,temp.getNumber(j,i));
		}
	}
}