#pragma once

class Vector3D
{
public:

	float m_x,m_y,m_z;

	Vector3D(void);
	Vector3D(float a, float b, float c);
	~Vector3D(void);

	float GetNorm();
	void Set(float a, float b, float c);
	Vector3D CrossProduct(Vector3D v);
	float DotProduct(Vector3D v);
	void Normalize();

	Vector3D operator + (Vector3D V);
	Vector3D operator - (Vector3D V);
	Vector3D operator * (float a);
	Vector3D operator / (float a);
	void operator += (Vector3D V);
	void operator -= (Vector3D V);
	void operator *= (float a);
};