#include "SphereTower.h"
#include "./SDL/include/SDL.h"


SphereTower::SphereTower(void)
{
	this->needToBeUpdated = true;
}


SphereTower::~SphereTower(void)
{
}


void SphereTower::update()
{
	this->m_position=this->m_newPosition;
	this->m_vitesse=this->m_newVitesse;
}

void SphereTower::think(int timeEllapsedSincePreviousFrame)
{
	
	if (this->needToBeUpdated)
	{
		
		//Vector3D sommeDesForces = this->CalculateSumOfForces();

		//this->SolveDiffEqEulerExplicite(sommeDesForces/m_particuleTab[i]->m_mass,step);
	}
}