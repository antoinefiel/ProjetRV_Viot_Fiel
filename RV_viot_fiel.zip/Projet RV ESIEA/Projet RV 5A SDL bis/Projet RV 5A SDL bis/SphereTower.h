#pragma once
#include "Dummy3DObject.h"
#include "Vector3D.h"

class SphereTower : public Dummy3DObject
{
public:
	SphereTower(void);
	~SphereTower(void);

	void update();
	void think(int timeEllapsedSincePreviousFrame);

private:
	Vector3D m_position;
	Vector3D m_vitesse;

	Vector3D m_newPosition;
	Vector3D m_newVitesse;

	bool needToBeUpdated;
};

