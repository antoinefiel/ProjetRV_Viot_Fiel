#pragma once

#include "Camera.h"
#include "Object3D.h"
#include "TowerOfGooApp.h"
#include "CreateSphereTracker.h"
#include "PhysicSolver.h"
#include "PhysicModel.h"

class TowerOfGooApp;

class Scene
{
public:
	Scene(void);
	~Scene(void);
	void doSwapLocking();
	void computeNextFrame(float timeEllapsedSincePreviousFrame);
	void populate();
	Camera* getActiveCamera();
	Object3D* getRoot();
	void draw();
	void recursiveDraw(Object3D* element);
	void clearOpenGL();
	void moveWorldToMatchCamera(Camera* arg);
	void recursiveThink(Object3D* element);
	void recursiveUpdate(Object3D* element);
	////
	void setApp(TowerOfGooApp* app);
	void sendMoveTracker(float x, float y,float z);
	void updateCreateSphereTrackerPosition();
	void insertSphere();
private:
	Object3D* root;
	Camera* activeCamera;
	PhysicSolver* physicSolver;
	float xTrackerMove;
	float yTrackerMove;
	float zTrackerMove;
	float timeEllapsedSincePreviousFrame;
	////
	int frameConter;
	TowerOfGooApp* app;
	CreateSphereTracker* createSphereTracker;
	

};

