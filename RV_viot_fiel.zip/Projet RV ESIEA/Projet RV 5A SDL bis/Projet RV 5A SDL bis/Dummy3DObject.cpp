#include "Dummy3DObject.h"


Dummy3DObject::Dummy3DObject(void)
{
}


Dummy3DObject::~Dummy3DObject(void)
{
}


void Dummy3DObject::think(float timeEllapsedSincePreviousFrame)
{
	return;
}

void Dummy3DObject::update()
{
	return;
}

bool Dummy3DObject::isLight()
{
	return false;
}

bool Dummy3DObject::isCamera()
{
	return false;
}

bool Dummy3DObject::isGeometry()
{
	return false;
}

void Dummy3DObject::draw()
{
	return;
}