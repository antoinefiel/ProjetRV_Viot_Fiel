#include "GroundPlane.h"
#include <Windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <GL/GL.h>


GroundPlane::GroundPlane(void)
{
}


GroundPlane::~GroundPlane(void)
{
}



bool GroundPlane::isGeometry()
{
	return true;
}

void GroundPlane::draw()
{
	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);

	// Modiy the attribs
	glEnable(GL_COLOR_MATERIAL);
	//glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glLineWidth(3.0f);

	glColor4f(0.5f,0.5f,0.5f,1.0f);

	glBegin(GL_QUADS);

	float value = 10;
	float floorOffset= -0.0f;
	glVertex3f(-value, floorOffset,		-value);
	glVertex3f(-value, floorOffset,		value);
	glVertex3f(value,  floorOffset,		value);
	glVertex3f(value,  floorOffset,		-value);

	glEnd();
	// Restore the attribs
	glPopAttrib();
	// restore the transformation matrix 
	glPopMatrix();
}
