#pragma once

#include "Dummy3DObject.h"

class GooSphere : public Dummy3DObject
{
public:
	GooSphere(void);
	~GooSphere(void);

	virtual bool isGeometry();
	virtual void draw();
};

