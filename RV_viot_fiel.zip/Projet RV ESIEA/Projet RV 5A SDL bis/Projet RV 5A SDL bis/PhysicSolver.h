#pragma once
#include "PhysicModel.h"
#include <vector>

class PhysicSolver
{
public:
	PhysicSolver(void);
	~PhysicSolver(void);

	void run(float deltaTime);
	bool canInsertSphereAtLocation(Vector3D positionOfNewSphere);
	void insertEntity(PhysicModel* entity, Vector3D location);

private:
	float cumulatedTime;
	float step;
	float maximalDistanceToLinkSphere;
	float minimalNumberOfSphereToLinkWith;
	std::vector<PhysicModel*> PhysicEntities;
};

