#pragma once
#include "Dummy3DObject.h"
class GroundPlane : public Dummy3DObject
{
public: 
	GroundPlane(void);
	~GroundPlane(void);

	virtual bool isGeometry();
	virtual void draw();
};

