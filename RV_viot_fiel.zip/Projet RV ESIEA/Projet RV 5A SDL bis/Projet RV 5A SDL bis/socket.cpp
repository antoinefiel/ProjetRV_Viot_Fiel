/*
   Copyright (C) 2001 Nate Miller nathanm@uci.edu

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

   See gpl.txt for more information regarding the GNU General Public License.
*/

#include "socket.h"
#include "err.h"

/*
=============
Set
=============
   Sets this socket to be equal to the passed socket
*/
void socket_t::Set(socket_t &s)
{
   sock = s.sock;
   addr.SetAddress(&s.addr);
}

/*
=============
Close
=============
   Close the socket.
*/
void socket_t::Close(void)
{
   if (sock != INVALID_SOCKET)
   {
#ifdef _WIN32
	   closesocket(sock);
#else
	   close(sock);
#endif
      sock = INVALID_SOCKET;
   }
}

/*
=============
CanRead
=============
   Tests the socket to see if there is data waiting to be read off of it.

   Returns 1 if there is data waiting, 0 if there is no data.
*/
bool socket_t::CanRead(void)
{
   if (sock == INVALID_SOCKET)
      return 0;

   fd_set set;
   timeval timeVal;

   // 0 so we return right away
   timeVal.tv_sec = 0;
   timeVal.tv_usec = 0;

   // what should happen when select fails?
   FD_ZERO(&set);
   FD_SET(sock, &set);
   int a = select(sock + 1, &set, NULL, NULL, &timeVal);

   return FD_ISSET(sock, &set) ? 1 : 0;
}

/*
=============
CanWrite
=============
   Test the socket to see if data can be sent on it.

   Returns 1 if data can be sent, 0 if not.
*/
bool socket_t::CanWrite(void)
{
   if (sock == INVALID_SOCKET)
      return 0;

   fd_set set;
   timeval timeVal;

   // 0 so we return right away
   timeVal.tv_sec = 0;
   timeVal.tv_usec = 0;

   // what should happen when select fails?
   FD_ZERO(&set);
   FD_SET(sock, &set);
   select(sock + 1, NULL, &set, NULL, &timeVal);

   return FD_ISSET(sock, &set) ? 1 : 0;
}

/*
=============
SendAll
=============
   Same as Send except that it ensure that all 'len' bytes of the buffer are
sent before it returns.

   Returns 'len' if all data was sent or SOCKET_ERROR on error.
*/
int socket_t::SendAll(const void *buffer, int len)
{
   int sent = 0;
   int res = 0;
   int left = len;
   const u_char *pos = (const u_char *) buffer;

   while (sent < len)
   {
      res = Send(pos + sent, left);
      
      if (res == SOCKET_ERROR)
         break;

      left -= res;
      sent += res;
   }

   return (res == SOCKET_ERROR) ? res : len;
}

/*
=============
SetAddress
=============
   Sets the internal address of this socket.  If host is not 0, then the
address will be set to host if it can be resolved.  If host is 0, the address
will be set to that of this machine.

   On error, throws error_t
*/
void socket_t::SetAddress(const char *host, unsigned short port)
{
   if (port <= 0)
      throw error_t("Port is <= 0");

   if (!IsValidSocket())
      throw error_t("Socket is not valid");

   memset(&addr, 0, sizeof(addr));

   sockaddr_in *taddr = addr.GetAddress();

   taddr->sin_family = AF_INET;         // address family
   taddr->sin_port = htons(port);       // port in network byte order
   taddr->sin_addr.s_addr = INADDR_ANY; // get IP automatically   
   
   if (host)
   {
      hostent *hostEntry = 0;

      // do we have a dotted ip address or a host name?
      if ((taddr->sin_addr.s_addr = inet_addr(host)) == INADDR_NONE)
      {
		 // if broadcast adress
		if (strcmp(host,"255.255.255.255")==0) return;

         // we have a host name, try and resolve it
         hostEntry = gethostbyname(host);

         // couldn't resolve it, bail out
         if (!hostEntry)
            throw error_t("Unable to resolve \"%s\"", host);
         else
            taddr->sin_addr.s_addr = 
             *((unsigned long *)*hostEntry->h_addr_list);
      }
   }
}
