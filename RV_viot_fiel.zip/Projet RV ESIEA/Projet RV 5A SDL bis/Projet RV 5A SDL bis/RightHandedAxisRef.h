#pragma once
#include "Dummy3DObject.h"
class RightHandedAxisRef : public Dummy3DObject
{
public:
	RightHandedAxisRef(void);
	~RightHandedAxisRef(void);
	bool isGeometry();
	void draw();

private:
	int arrowSubdiv;
	double arrowRadius;
	double arrowBegin;
};

