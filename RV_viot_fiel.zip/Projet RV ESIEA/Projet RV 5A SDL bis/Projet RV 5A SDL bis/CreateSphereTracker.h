#pragma once
#include "Dummy3DObject.h"
class CreateSphereTracker : public Dummy3DObject
{
public:
	CreateSphereTracker(void);
	~CreateSphereTracker(void);

	virtual void think(int timeEllapsedSincePreviousFrame);
	virtual bool isGeometry();
	virtual void draw();
};

