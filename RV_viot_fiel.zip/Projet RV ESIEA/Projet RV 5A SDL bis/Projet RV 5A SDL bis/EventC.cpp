#include "EventC.h"


EventC::EventC(void)
{
	this->isSDLEvent = true;
	this->isVRPNEvent = true;
}


EventC::~EventC(void)
{
}

EventC EventC::BuildEventFromSDLEvent(SDL_Event arg)
{
	EventC eventToReturn;
	eventToReturn.setSDLEvent(arg);
	return eventToReturn;
}

void EventC::process(TowerOfGooApp* arg)
{
	if(this->isSDLEvent)
	{
		SDL_Event EventCToProcess = this->sdlEvent;
		float xMove=0;
		float yMove=0;
		float zMove=0;

		if(EventCToProcess.type == SDL_KEYDOWN)
		{

			if(EventCToProcess.key.keysym.sym == SDLK_x)
			{
				arg->sendQuitSignal();
			}

			if(EventCToProcess.key.keysym.sym == SDLK_UP)
			{
				yMove=yMove+1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_DOWN)
			{
				yMove=yMove-1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_RIGHT)
			{
				xMove=xMove+1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_LEFT)
			{
				xMove=xMove-1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_PAGEUP)
			{
				zMove=zMove+1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_PAGEDOWN)
			{
				zMove=zMove-1;
			}
			arg->getScene()->sendMoveTracker(xMove,yMove,zMove);

			if(EventCToProcess.key.keysym.sym == SDLK_SPACE)
			{
				arg->getScene()->insertSphere();
			}
		}
		else if(EventCToProcess.type == SDL_KEYUP)
		{
			if(EventCToProcess.key.keysym.sym == SDLK_UP)
			{
				yMove=yMove-1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_DOWN)
			{
				yMove=yMove+1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_RIGHT)
			{
				xMove=xMove-1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_LEFT)
			{
				xMove=xMove+1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_PAGEUP)
			{
				zMove=zMove-1;
			}
			if(EventCToProcess.key.keysym.sym == SDLK_PAGEDOWN)
			{
				zMove=zMove+1;
			}
			arg->getScene()->sendMoveTracker(xMove,yMove,zMove);
		}
	}
	if(this->isVRPNEvent)
	{

	}
}

void EventC::setSDLEvent(SDL_Event arg)
{
	this->sdlEvent = arg;
	this->isSDLEvent = true;
}