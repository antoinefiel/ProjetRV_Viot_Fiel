#pragma once
#include "Object3D.h"

class Dummy3DObject : public Object3D
{
public:
	Dummy3DObject(void);
	~Dummy3DObject(void);

	virtual void update();
	virtual void think(float timeEllapsedSincePreviousFrame);
	virtual bool isLight();
	virtual bool isCamera();
	virtual bool isGeometry();
	virtual void draw();
};

