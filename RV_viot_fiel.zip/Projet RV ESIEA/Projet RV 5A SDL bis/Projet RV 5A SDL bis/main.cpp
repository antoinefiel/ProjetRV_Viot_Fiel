#include <Windows.h>
#include "glew-1.7.0\include\GL\glew.h"
#include "./SDL/include/SDL.h"

#include <gl/glu.h>

#include "TowerOfGooApp.h"
#include "EventC.h"
#include <gl/gl.h>
#include <GL/GL.h>

int main ( int argc, char *argv[] )
{
	SDL_Init ( SDL_INIT_VIDEO );
	SDL_WM_SetCaption ( "Tower Of Goo", NULL );
	SDL_SetVideoMode(640, 360, 32, SDL_HWSURFACE | SDL_GL_DOUBLEBUFFER | SDL_OPENGL /*| SDL_FULLSCREEN*/);
	SDL_GL_SetAttribute(SDL_GL_STEREO, 1);
	SDL_Event Event;
	TowerOfGooApp* app = new TowerOfGooApp();
	while (app->hasToKeepRunning())
		{
			while(SDL_PollEvent(&Event))
			{
				if(Event.type== SDL_QUIT)
				{
					app->sendQuitSignal();
				}
				else 
				{
					EventC sdlEvent = EventC::BuildEventFromSDLEvent(Event);
					app->pushEvent(sdlEvent);
				}	
			}
			app->run();
		}
	SDL_Quit();
	return 0;
}