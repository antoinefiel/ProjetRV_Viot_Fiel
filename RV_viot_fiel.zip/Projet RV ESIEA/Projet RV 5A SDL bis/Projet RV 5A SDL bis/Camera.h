#pragma once
#include "Object3D.h"
#include "Matrix4x4.h"

class Camera : public Object3D 
{
public:
	Camera(void);
	~Camera(void);
	bool isCamera();
	void think(float timeEllapsedSincePreviousFrame);
	void update();
	bool isLight();
	bool isGeometry();
	void draw();
	void doProjection(int eyeChoice);
private:
	Matrix4x4 projectionMatrix;
};

