#pragma once
#include "TowerOfGooApp.h"
#include "./SDL/include/SDL.h"


class TowerOfGooApp;

class EventC
{
public:
	EventC(void);
	~EventC(void);
	void process(TowerOfGooApp* arg);
	static EventC BuildEventFromSDLEvent(SDL_Event arg);
	void setSDLEvent(SDL_Event arg);
private:
	bool isSDLEvent;
	SDL_Event sdlEvent;
	bool isVRPNEvent;

};

