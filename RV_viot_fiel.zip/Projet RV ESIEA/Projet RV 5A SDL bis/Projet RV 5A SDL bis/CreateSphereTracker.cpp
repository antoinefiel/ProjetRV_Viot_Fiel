#define _USE_MATH_DEFINES
#include <cmath>

#include "CreateSphereTracker.h"

#include <Windows.h>

#include <gl/glu.h>
#include <GL/GL.h>
#include <gl/gl.h>

CreateSphereTracker::CreateSphereTracker(void)
{
}


CreateSphereTracker::~CreateSphereTracker(void)
{
}

void CreateSphereTracker::think(int timeEllapsedSincePreviousFrame)
{

}

bool CreateSphereTracker::isGeometry()
{
	return true;
}

void CreateSphereTracker::draw()
{

	int arrowSubdiv=12;
	double arrowRadius=0.05f;
	double arrowBegin=0.9f;

	glPushMatrix();
	glPushAttrib(GL_ALL_ATTRIB_BITS);

	// Modiy the attribs
	glEnable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glLineWidth(3.0f);

	// Draw the ref
	
	// X AXIS
	////////////////////////////////////
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f,0.0f,0.0f,1.0f);
		glVertex3f(1.0f,0.0f,0.0f);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) arrowBegin;
			GLfloat y = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat z = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(1.0f,0.0f,0.0f,1.0f);
		glVertex3f((GLfloat)arrowBegin,0.0f,0.0f);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) arrowBegin;
			GLfloat y = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat z = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_LINES);
		glColor4f(1.0f,0.0f,0.0f,1.0f);
		glVertex3f((GLfloat)arrowBegin,0.0f,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);
		glEnd();
	}
	////////////////////////////////////
	// Y AXIS
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.0f,1.0f,0.0f,1.0f);
		glVertex3f(0.0f,1.0f,0.0f);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat y = (GLfloat) arrowBegin;
			GLfloat z = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.0f,1.0f,0.0f,1.0f);
		glVertex3f(0.0f,(GLfloat) arrowBegin,0.0f);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat y = (GLfloat) arrowBegin;
			GLfloat z = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_LINES);
		glColor4f(0.0f,1.0f,0.0f,1.0f);
		glVertex3f(0.0f,(GLfloat) arrowBegin,0.0f);
		glVertex3f(0.0f,0.0f,0.0f);
		glEnd();
	}

	// Z AXIS
	////////////////////////////////////
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.0f,0.0f,1.0f,1.0f);
		glVertex3f(0.0f,0.0f,1.0f);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat y = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			GLfloat z = (GLfloat) arrowBegin;
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_TRIANGLE_FAN);
		glColor4f(0.0f,0.0f,1.0f,1.0f);
		glVertex3f(0.0f,0.0f,(GLfloat)arrowBegin);
		for (int i = 0;i<=arrowSubdiv;i++)
		{
			GLfloat x = (GLfloat) (arrowRadius*cos(2*i*M_PI/(arrowSubdiv)));
			GLfloat y = (GLfloat) (arrowRadius*sin(2*i*M_PI/(arrowSubdiv)));
			GLfloat z = (GLfloat) arrowBegin;
			glVertex3f(x,y,z);
		}
		glEnd();
	}
	{
		glBegin(GL_LINES);
		glColor4f(0.0f,0.0f,1.0f,1.0f);
		glVertex3f(0.0f,0.0f,(GLfloat)arrowBegin);
		glVertex3f(0.0f,0.0f,0.0f);
		glEnd();
	}
	////////////////////////////////////

	// Restore the attribs
	glPopAttrib();
	// restore the transformation matrix 
	glPopMatrix();
}