#include "gl_utils.h"
#define _USE_MATH_DEFINES
#include <math.h>


// To draw the referential 
BOOL drawRef(float coef, BOOL refCenter , float size)
{
	// Save the referential
	glPushMatrix();

	// apply the scale factor
	glScalef(coef,coef,coef);

	// get the attributes to be re-applied after the drawings
	GLint shader;
	GLfloat lineWidth,pointSize;
	glGetIntegerv(GL_CURRENT_PROGRAM,&shader);
	glGetFloatv(GL_LINE_WIDTH,&lineWidth);
	glGetFloatv(GL_POINT_SIZE,&pointSize);

	// No shader applied
	glUseProgram(0);

	// Set the first channel of texture
	glActiveTexture(GL_TEXTURE0);

	// save all the attribs
	glPushAttrib(GL_TEXTURE_2D|GL_LIGHTING|GL_COLOR_MATERIAL);

	// Modiy the attribs
	glEnable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);

	glLineWidth(3.0f);

	// Draw the ref

//	 X AXIS
//	/*glBegin(GL_TRIANGLE_FAN);
//		glColor4f(1.0f,0.0f,0.0f,1.0f);
//		glVertex3f(1.0f,0.0f,0.0f);
//		
//    for (int i = 0; i <= 12; i++){
//    glVertex3f(0.9f,0.05f*cos(M_PI*i/6.0f),0.05f*sin(M_PI*i/6.0f));
//    }
//
//	glEnd();
//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f(1.0f,0.0f,0.0f,1.0f);
//		glVertex3f(0.85f,0.0f,0.0f);
//		// A COMPLETER
//	glEnd();
//	glBegin(GL_LINES);
//		glColor4f(1.0f,0.0f,0.0f,1.0f);
//    glVertex3f(0.0f,0.0f,0.0f);
//    glVertex3f(1.0f,0.0f,0.0f);
//	glEnd();
//
//	 Y AXIS
//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f(0.0f,1.0f,0.0f,1.0f);
//		glVertex3f(0.0f,1.0f,0.0f);
//
//    for(int j = 0; j <= 12; j++){
//      glVertex3f(0.05f*cos(M_PI*j/6.0f),0.9f,0.05f*sin(M_PI*j/6.0f));
//    }
//
//		 A COMPLETER
//	glEnd();
//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f(0.0f,1.0f,0.0f,1.0f);
//		glVertex3f(0.0f,0.85f,0.0f);
//		// A COMPLETER
//	glEnd();
//	glBegin(GL_LINES);
//		glColor4f(0.0f,1.0f,0.0f,1.0f);
//    glVertex3f(0.0f,0.0f,0.0f);
//    glVertex3f(0.0f,1.0f,0.0f);
//		 A COMPLETER
//	glEnd();
//
//	 Z AXIS
//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f(0.0f,0.0f,1.0f,1.0f);
//		glVertex3f(0.0f,0.0f,1.0f);
//
//    for(int k = 0; k <=12; k++){
//  glVertex3f(0.05f*cos(M_PI*k/6.0f),0.05f*sin(M_PI*k/6.0f),0.9f);
//    }
//		 A COMPLETER
//	glEnd();
//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f(0.0f,0.0f,1.0f,1.0f);
//		glVertex3f(0.0f,0.0f,0.85f);
//		// A COMPLETER
//	glEnd();
//	glBegin(GL_LINES);
//		glColor4f(0.0f,0.0f,1.0f,1.0f);
//    glVertex3f(0.0f,0.0f,0.0f);
//    glVertex3f(0.0f,0.0f,1.0f);
//		 A COMPLETER
//	glEnd();*/
//
//	 Draw a point to "see" the center of the referential (to represent the light for instance)
///*	if(refCenter)
//	{
//		glPointSize(size);
//		glBegin(GL_POINTS);
//			glColor4f(1.0f,1.0f,1.0f,1.0f);
//			glVertex3f(0.0f,0.0f,0.0f);
//		glEnd();
//	}*/
//

	// Restore the attribs
	glPopAttrib();

	// Restore the parameters stored before drawing
	glUseProgram(shader);
	glLineWidth(lineWidth);
	glPointSize(pointSize);

	// restore the transformation matrix 
	glPopMatrix();

	return TRUE;
}


// To draw the grid 
BOOL drawGrid(float size, int nbLines)
{
	if(nbLines<2) nbLines = 2;

	// Save the transformation matrix
	glPushMatrix();

	// apply the scale factor
	glScalef(size,size,size);

  //rotation
  //glRotatef(90.0f,1.0f,0.0f,0.0f);

	// Save the parameters which can change during the drawing of the grid
	GLint shader;
	GLfloat lineWidth;
	glGetIntegerv(GL_CURRENT_PROGRAM,&shader);
	glGetFloatv(GL_LINE_WIDTH,&lineWidth);

	// No shader used
	glUseProgram(0);

	// Channel 0 for texture used
	glActiveTexture(GL_TEXTURE0);

	// Save the attribs before drawing
	glPushAttrib(GL_TEXTURE_2D|GL_LIGHTING|GL_COLOR_MATERIAL);

	glEnable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);

	glLineWidth(1.5f);

	// Draw the grid
	//glBegin(GL_LINES);
	//	glColor4f(0.2f,0.2f,0.2f,1.0f);
	//	for (int l = 0; l < nbLines; l++){

 //     glVertex3f(-0.5f,0.0f,-0.5f+l/(float)(nbLines-1));
 //     glVertex3f(0.5f,0.0f,-0.5f+l/(float)(nbLines-1));

 //    glVertex3f(-0.5f+l/(float)(nbLines-1),0.0f,-0.5f);
 //    glVertex3f(-0.5f+l/(float)(nbLines-1),0.0f,0.5f);

 //   }
	//glEnd();


	// Restore the attribs
	glPopAttrib();

	// Restore the parameters stored before drawing
	glUseProgram(shader);
	glLineWidth(lineWidth);

	// restore the transformation matrix
	glPopMatrix();

	return TRUE;
}

// To draw the Cube
BOOL drawCube(float size, GLuint textid)
{
	

	// Save the transformation matrix
	glPushMatrix();

	// apply the scale factor
	glScalef(size,size,size);

  
	// Save the parameters which can change during the drawing of the grid
	GLint shader;
	glGetIntegerv(GL_CURRENT_PROGRAM,&shader);

  // No shader used
	glUseProgram(0);



	// Save the attribs before drawing
	glPushAttrib(GL_TEXTURE_2D|GL_LIGHTING|GL_COLOR_MATERIAL);

	//glEnable(GL_COLOR_MATERIAL);
	//glDisable(GL_LIGHTING);
  glEnable(GL_LIGHTING);

	//glDisable(GL_TEXTURE_2D);
  glEnable(GL_TEXTURE_2D);
	// Channel 0 for texture used
	glActiveTexture(GL_TEXTURE0);

  glBindTexture(GL_TEXTURE_2D,textid);

  // Draw the cube
	glBegin(GL_QUADS);

  //-Z
  glColor3f(0.0f,0.0f,1.0f);
  glNormal3f(0.0f,0.0f,-1.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(0.5f,-0.5f,-0.5f);
  glTexCoord2f(1.0f,0.0f);  glVertex3f(-0.5f,-0.5f,-0.5f); 
  glTexCoord2f(1.0f,1.0f);  glVertex3f(-0.5f,0.5f,-0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(0.5f,0.5f,-0.5f);
 

  //+X
  glColor3f(1.0f,0.0f,0.0f);
  glNormal3f(1.0f,0.0f,0.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(0.5f,-0.5f,0.5f); 
  glTexCoord2f(1.0f,0.0f);  glVertex3f(0.5f,-0.5f,-0.5f);
  glTexCoord2f(1.0f,1.0f);  glVertex3f(0.5f,0.5f,-0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(0.5f,0.5f,0.5f);
  

  //+Z
  glColor3f(0.0f,0.0f,1.0f);
  glNormal3f(0.0f,0.0f,1.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(0.5f,-0.5f,0.5f);
  glTexCoord2f(1.0f,0.0f);  glVertex3f(0.5f,0.5f,0.5f);
  glTexCoord2f(1.0f,1.0f);  glVertex3f(-0.5f,0.5f,0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(-0.5f,-0.5f,0.5f);

  //-X
  glColor3f(1.0f,0.0f,0.0f);
  glNormal3f(-1.0f,0.0f,0.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(-0.5f,-0.5f,0.5f);
  glTexCoord2f(1.0f,0.0f);  glVertex3f(-0.5f,0.5f,0.5f);
  glTexCoord2f(1.0f,1.0f);  glVertex3f(-0.5f,0.5f,-0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(-0.5f,-0.5f,-0.5f);

  //-Y
  glColor3f(0.0f,1.0f,0.0f);
  glNormal3f(0.0f,-1.0f,0.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(0.5f,-0.5f,0.5f);
  glTexCoord2f(1.0f,0.0f);  glVertex3f(-0.5f,-0.5f,0.5f);
  glTexCoord2f(1.0f,1.0f);  glVertex3f(-0.5f,-0.5f,-0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(0.5f,-0.5f,-0.5f);

  //+Y
  glColor3f(0.0f,1.0f,0.0f);
  glNormal3f(0.0f,1.0f,0.0f);
  glTexCoord2f(0.0f,0.0f);  glVertex3f(-0.5f,0.5f,0.5f);
  glTexCoord2f(1.0f,0.0f);  glVertex3f(0.5f,0.5f,0.5f);
  glTexCoord2f(1.0f,1.0f);  glVertex3f(0.5f,0.5f,-0.5f);
  glTexCoord2f(0.0f,1.0f);  glVertex3f(-0.5f,0.5f,-0.5f);
 

  glEnd();
  
  glBindTexture(GL_TEXTURE_2D,0);

	// Restore the attribs
	glPopAttrib();

	// Restore the parameters stored before drawing
	glUseProgram(shader);

	// restore the transformation matrix
	glPopMatrix();

	return TRUE;
}


// Texture
//