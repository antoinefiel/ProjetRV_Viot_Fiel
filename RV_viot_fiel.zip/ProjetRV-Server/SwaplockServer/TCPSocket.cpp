/*
   Copyright (C) 2001 Nate Miller nathanm@uci.edu

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

   See gpl.txt for more information regarding the GNU General Public License.
*/
#include "TCPSocket.h"
#include "err.h"

/*
=============
Connect
=============
   Try and connect to 'host' on 'port'.

   On error, throws error_t.
*/
int TCPSocket_t::Connect(const char *host, unsigned short port)
{
   // Make sure we have valid data
   if (!host)
      throw error_t("Null host name");

   if (!port)
      throw error_t("Port is 0");

   // If this socket is bound already, close it
   if (IsValidSocket())
      Close();

   // try and create a socket
   CreateSocket();

   SetAddress(host, port);
   // connect the socket to the remote system
   return connect(sock, (sockaddr *) addr.GetAddress(),sizeof(*addr.GetAddress()));
   //if (connect(sock, (sockaddr *) addr.GetAddress(),sizeof(*addr.GetAddress())) == SOCKET_ERROR)
	   //throw error_t("Failed to connect to \"%s\" on port %d", host, port);
}

/*
=============
Listen
=============
   Make this socket listen on 'port' with a maximum number of clients waiting
to connect of 'back'.

   On error, throws error_t.
*/
void TCPSocket_t::Listen(unsigned short port, int back)
{
   // If there is a socket already, close it
   if (IsValidSocket())
      Close();

   // Create a socket
   CreateSocket();
   
   SetAddress(0, port);

   // Bind the socket to the above address
   if (bind(sock, (sockaddr *) addr.GetAddress(), sizeof(*addr.GetAddress()))
    == SOCKET_ERROR)
      throw error_t("Unable to bind socket");

   // Try and listen 
   if (listen(sock, back) == SOCKET_ERROR)
      throw error_t("Unable to listen on socket");
}

/*
=============
Accept
=============
   The accept method accepts a connection on this socket when it is in 
listening mode and there is a client waiting to connect.  The client socket
that was accepted is stored in the passed parameter.

   On error, throws error_t.
*/
void TCPSocket_t::Accept(TCPSocket_t &newSock)
{
   // If we don't have a valid socket we can't accept, return 0
   if (!IsValidSocket())
      throw error_t("Socket is not valid");

   // Address information of client machine
   sockaddr_in clientAddr;
   int size = sizeof(clientAddr);

   // Accept the connection
   newSock.sock = accept(sock, (sockaddr *) &clientAddr, &size);
   newSock.addr.SetAddress(&clientAddr);

   if (newSock.sock == INVALID_SOCKET)
      throw error_t("Accept error");
}

/*
=============
Send
=============
   Send 'len' number of bytes in 'buffer'.  

   This method returns the number of bytes that were sent.  May not always send
'len' bytes.  On error, returns SOCKET_ERROR.
*/
int TCPSocket_t::Send(const void *buffer, int len)
{
   if (!IsValidSocket())
      return SOCKET_ERROR;

   return send(sock, (char *) buffer, len, 0);
}

/*
=============
Read
=============
   This method reads data off of the socket if it is avaliable.  If there is no 
data, this function will wait until there is data.  The read data is placed
into 'dest' where 'len' contains the size of the 'dest' buffer.

   If return is > 0 then the return value of bytes were read and placed into the
   buffer.
   If return is 0 the connection was closed gracefully.  
   If return is SOCKET_ERROR then there was an error.
*/
int TCPSocket_t::Read(void *dest, const int &len)
{
	return recv(sock, (char *) dest, len, 0);
}

/*
=============
CreateSocket
=============
   Creates a stream socket.  

   On error, throws error_t.
*/
void TCPSocket_t::CreateSocket(void)
{
   if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
      throw error_t("Failed to create SOCK_STREAM socket");
	  
	// D�sactive algo de Nagle
   BOOL bOptVal = TRUE;
   int bOptLen = sizeof(BOOL);
   int a=setsockopt(sock,IPPROTO_TCP,TCP_NODELAY,(char*)&bOptVal, bOptLen);
}