#pragma once

#include "TCPSocket.h"

class CTCPConnection
{
public:
	
	CTCPConnection(void);
	~CTCPConnection(void);

	bool			Init(char* serverIP, unsigned short port);
	bool			Close();
	void			SendData(void* s, int size);
	bool			ReadData(void* s, int size);
	bool			DataWaiting();
	bool			IsConnected();

private:

	TCPSocket_t*	workingSocket;
	TCPSocket_t*	listeningSocket;
	char*			serverIP;
	unsigned short	port;
	bool			connected;
};
