#include "WiiButton.h"


//#include "Tracker.h"

void VRPN_CALLBACK handle_tracker2(void* userData, const vrpn_BUTTONCB t)
{
	vrpn_float64 *buffer = (vrpn_float64*)userData;

	//memcpy(buffer, t.state, 3*sizeof(vrpn_float64));
	
}

WiiButton::WiiButton(std::string trackerVM)

{
	typedef	struct _vrpn_BUTTONCB {
	struct timeval	msg_time;	// Time of button press/release
	vrpn_int32	button;		// Which button (numbered from zero)
	vrpn_int32	state;		// button state (0 = off, 1 = on) 
} vrpn_BUTTONCB;
typedef void (VRPN_CALLBACK *vrpn_BUTTONCHANGEHANDLER)(void *userdata,
					 const vrpn_BUTTONCB info);

	memset(buffer, 0, 7*sizeof(vrpn_float64));

	vrpnTracker = new vrpn_Tracker_Remote(trackerVM.c_str());
	//vrpnTracker->register_change_handler(
	//	(buffer, handle_tracker2);

	clientPosition = NULL;
	clientRotation = NULL;
	clientNewPosition = NULL;
	clientNewRotation = NULL;
}

WiiButton::~WiiButton()
{
	delete vrpnTracker;

	if(clientPosition != NULL) 
		delete[] clientPosition;
	if(clientRotation != NULL)
		delete[] clientRotation;
	if(clientNewPosition != NULL)
		delete[] clientNewPosition;
	if(clientNewRotation != NULL)
		delete[] clientNewRotation;
}

void WiiButton::trackingLoop()
{
	vrpnTracker->mainloop();

	if(clientNewPosition == NULL)
	{
		if(clientPosition == NULL)
		{
			clientPosition = new vrpn_float64[3];
			clientRotation = new vrpn_float64[4];

			memcpy(clientPosition, buffer, 3*sizeof(vrpn_float64));
			memcpy(clientRotation, &buffer[3], 4*sizeof(vrpn_float64));
		}
		else
		{
			clientNewPosition = new vrpn_float64[3];
			clientNewRotation = new vrpn_float64[4];

			memcpy(clientNewPosition, buffer, 3*sizeof(vrpn_float64));
			memcpy(clientNewRotation, &buffer[3], 4*sizeof(vrpn_float64));
		}
	}
	else
	{
		memcpy(clientPosition, clientNewPosition, 3*sizeof(vrpn_float64));
		memcpy(clientRotation, clientNewRotation, 4*sizeof(vrpn_float64));
		memcpy(clientNewPosition, buffer, 3*sizeof(vrpn_float64));
		memcpy(clientNewRotation, &buffer[3], 4*sizeof(vrpn_float64));
	}
}





