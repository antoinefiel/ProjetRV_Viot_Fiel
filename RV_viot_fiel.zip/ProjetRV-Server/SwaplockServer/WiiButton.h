#pragma once

#include "../vrpn/includes/vrpn_Tracker.h"
#include "../vrpn/includes/vrpn_Button.h"
#include "gl_utils.h"
#include <cmath>

using namespace std;

#define defaultButtonServer "xl0@192.168.2.230:3884"


class WiiButton
{
	public:
		WiiButton(std::string);
		~WiiButton();
		void trackingLoop();

		
		vrpn_Tracker_Remote* vrpnTracker;
		vrpn_float64 buffer[7];
		vrpn_float64 *clientPosition, *clientRotation, *clientNewPosition, *clientNewRotation;
};
