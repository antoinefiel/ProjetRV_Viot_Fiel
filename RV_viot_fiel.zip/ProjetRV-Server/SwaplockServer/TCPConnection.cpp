#include "TCPConnection.h"
#include <stdio.h>

CTCPConnection::CTCPConnection(void)
{
	workingSocket=NULL;
	listeningSocket=NULL;
	connected=false;
}

CTCPConnection::~CTCPConnection(void)
{
	Close();
}

bool CTCPConnection::Init(char* serverIP, unsigned short TCPPort)
{
	bool ret=false;

	this->serverIP=serverIP;
	this->port=TCPPort;

	if (!connected)
	{
		WinsockInit();
		workingSocket = new TCPSocket_t;
		listeningSocket = new TCPSocket_t;
		if (!serverIP)
		{
			printf("\n\nAttente de connexion du client sur le port %d", TCPPort);
			listeningSocket->Listen(TCPPort,1);
			listeningSocket->Accept(*workingSocket);
			printf("\n   Connexion avec le client etablie\n\n\n");
			connected=true;
			ret=true;
		}
		else
		{
			printf("\n\nConnexion au serveur sur le port %d", TCPPort);
			if (workingSocket->Connect(serverIP, TCPPort)!=SOCKET_ERROR)
			{
				connected=true;
				ret=true;
				printf("\n   Connexion avec le serveur etablie\n\n\n");
			}
			else printf("\n   Can't connect to server");
		}
	}
	return ret;
}

bool CTCPConnection::Close()
{
	bool ret=false;
	if (workingSocket!=NULL)
	{
		workingSocket->Close();
		delete workingSocket;
		workingSocket=NULL;
	}
	if (listeningSocket!=NULL)
	{
		listeningSocket->Close();
		delete listeningSocket;
		listeningSocket=NULL;
	}
	connected=false;
	WinsockShutdown();
	ret=true;

	return ret;
}

void CTCPConnection::SendData(void* s, int size)
{
	if (connected)
	{
		if(workingSocket->CanWrite())
		{
			int ret;
			do
			{
				ret=workingSocket->Send(s,size);
			}
			while(ret!=SOCKET_ERROR && ret!=size);
			if (ret==SOCKET_ERROR)
				connected=false;
		}
	}
}

bool CTCPConnection::ReadData(void* s, int size)
{
	bool ret=false;
	if (connected)
	{
		if (workingSocket->CanRead())
		{
			int alive = workingSocket->Read(s,size);

			if (alive<1)
				connected=false;
			else if (alive>0)
			{
				ret=true;
				connected=true;
			}
		}
	}

	return ret;
}

bool CTCPConnection::DataWaiting()
{
	return workingSocket->CanRead();
}

bool CTCPConnection::IsConnected()
{
	int test=-1;
	SendData((void*)&test,sizeof(int));
	return connected;
}