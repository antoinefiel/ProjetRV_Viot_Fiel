#include <stdio.h>
#include "TCPConnection.h"
#include <conio.h>
#include <SDL.h>
#include "Tracker.h"

Tracker* trackerGlasses;
Tracker* trackerHand;
Tracker* trackerButton;

bool done = false;


float xMove=0;
float yMove=0;
float zMove=0;
bool createSphere = false;

double head[16];
double hand[16];


void processEvent(float* tab , SDL_Event* SDLevent)
{

	tab[16]=0;

	if(SDLevent->type == SDL_KEYDOWN)
	{

		if(SDLevent->key.keysym.sym == SDLK_UP)
		{
			yMove=yMove+1;
		}
		if(SDLevent->key.keysym.sym == SDLK_DOWN)
		{
			yMove=yMove-1;
		}
		if(SDLevent->key.keysym.sym == SDLK_RIGHT)
		{
			xMove=xMove+1;
		}
		if(SDLevent->key.keysym.sym == SDLK_LEFT)
		{
			xMove=xMove-1;
		}
		if(SDLevent->key.keysym.sym == SDLK_PAGEUP)
		{
			zMove=zMove+1;
		}
		if(SDLevent->key.keysym.sym == SDLK_PAGEDOWN)
		{
			zMove=zMove-1;
		}

		if(SDLevent->key.keysym.sym == SDLK_SPACE)
		{
			createSphere=1;
		}
		if(SDLevent->key.keysym.sym == SDLK_x)
		{
			done=true;
		}
	}
	else if(SDLevent->type == SDL_KEYUP)
	{
		if(SDLevent->key.keysym.sym == SDLK_UP)
		{
			yMove=yMove-1;
		}
		if(SDLevent->key.keysym.sym == SDLK_DOWN)
		{
			yMove=yMove+1;
		}
		if(SDLevent->key.keysym.sym == SDLK_RIGHT)
		{
			xMove=xMove-1;
		}
		if(SDLevent->key.keysym.sym == SDLK_LEFT)
		{
			xMove=xMove+1;
		}
		if(SDLevent->key.keysym.sym == SDLK_PAGEUP)
		{
			zMove=zMove-1;
		}
		if(SDLevent->key.keysym.sym == SDLK_PAGEDOWN)
		{
			zMove=zMove+1;
		}
	}
	tab[2]=xMove;
	tab[3]=yMove;
	tab[4]=zMove;
}

int main(int argc, char* argv[])
{
	// Connexions
	trackerHand = new Tracker(defaultHandServer);
	trackerGlasses= new Tracker(defaultGlassesServer);
	trackerButton= new Tracker(defaultButtonServer);

	CTCPConnection connexion1;
	CTCPConnection connexion2;

	SDL_Init ( SDL_INIT_TIMER);
	SDL_Init ( SDL_INIT_VIDEO );

	SDL_Init(SDL_INIT_VIDEO); // Initialisation de la SDL
 
    SDL_SetVideoMode(64, 64, 32, SDL_HWSURFACE); // Ouverture de la fen�tre
	SDL_WM_SetCaption("window Server!", NULL);
	

	// initialisation Winsock /////////////////////////////////////////////////
	printf("Init Connexion\n");

	// TCP servers configuration
	FILE *fichier;
	errno_t ret=fopen_s(&fichier,"config/swaplock.cfg", "rt");
	int swaplockport1, swaplockport2;
	char swaplockserver[16];
	fscanf_s(fichier, "%s", swaplockserver,sizeof(swaplockserver));
	fscanf_s(fichier, "%d", &swaplockport1);
	fscanf_s(fichier, "%d", &swaplockport2);
	
	bool useClient1=true;
	bool useClient2=false;

	if(useClient1)
	{
		unsigned short TCPportserver1 = swaplockport1;
		connexion1.Init(NULL,TCPportserver1);
	}
	
	if(useClient2)
	{
		unsigned short TCPportserver2 = swaplockport2;
		connexion2.Init(NULL,TCPportserver2);
	}
	///////////////////////////////////////////////////////////////////////////

	// boucle principale


	bool client1IsSwapReady=false;
	bool client1IsSwapDone=false;
	
	bool client2IsSwapReady=false;
	bool client2IsSwapDone=false;

	bool hasToOrderSwap = false;
	bool hasToOrderScene = false;

	
	//dataOut struct 17 floats ; 0-16
	//0 : order : 1 = computeScene; 2 = doSwap
	//1 : update time
	//2,3,4 : x,y,z position of tracker
	//5,6,7,8 : x,y,z,w orientation of tracker
	//9,10,11 : x,y,z position of camera
	//12,13,14,15 : x,y,z,w orientation of camera
	//16 : add sphere order

	
#define tabSize 17
	float dataOut[tabSize];

	for (int i = 0; i<tabSize; i++)
	{
		dataOut[i]=0;
	}

	int previousTime = SDL_GetTicks();
	while(!done)
	{
		trackerHand->trackingLoop();
		trackerHand->getTransform(&hand[0]);

		trackerGlasses->trackingLoop();
		trackerGlasses->getTransform(&head[0]);

		/*trackerButton->trackingLoop();
		trackerButton->getTransform(&head[0]);*/

		SDL_Event Event;
		while(SDL_PollEvent(&Event))
		{
			processEvent(&dataOut[0], &Event);
		}
		
		// lecture des donn�es des 2 clients
		if(useClient1)
		{
			int client1Input;
			while(connexion1.DataWaiting())
			{
				if (connexion1.ReadData(&client1Input, sizeof(int)))
				{
					if (client1Input == 1)
					{
						client1IsSwapReady = true;
						printf("le client 1 a calcule la scene et est pret a swapper\n");
					}
					else if (client1Input == 2)
					{
						client1IsSwapDone = true;
						printf("le client 1 a swappe et est pret a calculer la scene\n");
					}
				}
			}
		}

		if(useClient2)
		{
			int client2Input;
			while(connexion2.DataWaiting())
			{
				if (connexion2.ReadData(&client2Input, sizeof(int)))
				{
					if (client2Input == 1)
					{
						printf("le client 2 a calcule la scene et est pret a swapper\n");
						client2IsSwapReady = true;
					}
					else if (client2Input == 2)
					{
						printf("le client 2 a swappe et est pret a calculer la scene\n");
						client2IsSwapDone = true;
					}
				}
			}
		}

		if(useClient1 && useClient2)
		{
			hasToOrderScene=client1IsSwapDone && client2IsSwapDone;
		}
		else if(useClient2)
		{
			hasToOrderScene=client2IsSwapDone;
		}
		else if(useClient1)
		{
			hasToOrderScene=client1IsSwapDone;
		}



		if(useClient1 && useClient2)
		{
			hasToOrderSwap=client1IsSwapReady && client2IsSwapReady;
		}
		else if(useClient2)
		{
			hasToOrderSwap=client2IsSwapReady;
		}
		else if(useClient1)
		{
			hasToOrderSwap=client1IsSwapReady;
		}

		// �criture

		if(hasToOrderScene)
		{
			int currentTime = SDL_GetTicks();
			if (currentTime-previousTime>5)
			{
				dataOut[0]=1;
				dataOut[1]=currentTime-previousTime;
				dataOut[2]=hand[12];
				dataOut[3]=hand[13];
				dataOut[4]=hand[14];
				dataOut[9]=head[12];
				dataOut[10]=head[13];
				dataOut[11]=-head[14];
				dataOut[16]=createSphere;
				createSphere=false;
				previousTime=currentTime;
				if(useClient1) 
				{
					printf("j'envoie l'ordre au client 1 de calculer la scene\n");
					client1IsSwapDone=false;
					connexion1.SendData((void *)&dataOut, tabSize*sizeof(float));
				}
				if(useClient2) 
				{
					printf("j'envoie l'ordre au client 2 de calculer la scene\n");
					client2IsSwapDone=false;
					connexion2.SendData((void *)&dataOut, tabSize*sizeof(float));
				}
			}
			
		}

		if(hasToOrderSwap)
		{
			dataOut[0]=2;// swapLockOrder
			if(useClient1) 
			{
				printf("j'envoie l'ordre au client 1 de swapper\n");
				client1IsSwapReady=false;
				connexion1.SendData((void *)&dataOut, tabSize*sizeof(float));
				
			}
			if(useClient2)
			{
				printf("j'envoie l'ordre au client 2 de swapper\n");
				client2IsSwapReady=false;
				connexion2.SendData((void *)&dataOut, tabSize*sizeof(float));
			}
		}
	}

	return 0;
}

