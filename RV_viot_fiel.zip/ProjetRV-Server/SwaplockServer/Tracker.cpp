#include "Tracker.h"

void VRPN_CALLBACK handle_tracker(void* userData, const vrpn_TRACKERCB t)
{
	vrpn_float64 *buffer = (vrpn_float64*)userData;

	memcpy(buffer, t.pos, 3*sizeof(vrpn_float64));
	memcpy(&buffer[3], t.quat, 4*sizeof(vrpn_float64));
}

Tracker::Tracker(std::string trackerVM)
{
	memset(buffer, 0, 7*sizeof(vrpn_float64));

	vrpnTracker = new vrpn_Tracker_Remote(trackerVM.c_str());
	vrpnTracker->register_change_handler(buffer, handle_tracker);

	clientPosition = NULL;
	clientRotation = NULL;
	clientNewPosition = NULL;
	clientNewRotation = NULL;
}

Tracker::~Tracker()
{
	delete vrpnTracker;

	if(clientPosition != NULL) 
		delete[] clientPosition;
	if(clientRotation != NULL)
		delete[] clientRotation;
	if(clientNewPosition != NULL)
		delete[] clientNewPosition;
	if(clientNewRotation != NULL)
		delete[] clientNewRotation;
}

void Tracker::trackingLoop()
{
	vrpnTracker->mainloop();

	if(clientNewPosition == NULL)
	{
		if(clientPosition == NULL)
		{
			clientPosition = new vrpn_float64[3];
			clientRotation = new vrpn_float64[4];

			memcpy(clientPosition, buffer, 3*sizeof(vrpn_float64));
			memcpy(clientRotation, &buffer[3], 4*sizeof(vrpn_float64));
		}
		else
		{
			clientNewPosition = new vrpn_float64[3];
			clientNewRotation = new vrpn_float64[4];

			memcpy(clientNewPosition, buffer, 3*sizeof(vrpn_float64));
			memcpy(clientNewRotation, &buffer[3], 4*sizeof(vrpn_float64));
		}
	}
	else
	{
		memcpy(clientPosition, clientNewPosition, 3*sizeof(vrpn_float64));
		memcpy(clientRotation, clientNewRotation, 4*sizeof(vrpn_float64));
		memcpy(clientNewPosition, buffer, 3*sizeof(vrpn_float64));
		memcpy(clientNewRotation, &buffer[3], 4*sizeof(vrpn_float64));
	}
}

void Tracker::getTransform(double* mat)
{
	if(mat != NULL)
	{
		double clientFinalPosition[3] = {0}, clientFinalRotation[4] = {0,0,0,1};

		if(clientNewPosition != NULL)
		{
			lerp(clientFinalPosition, clientPosition, clientNewPosition, interpolationCoef);
	
		}
		else
		{
			memcpy(clientFinalPosition, clientPosition, 3*sizeof(vrpn_float64));
			memcpy(clientFinalRotation, clientRotation, 4*sizeof(vrpn_float64));
		}

		double a = 1,//clientFinalRotation[3], 
			   b = 1,//clientFinalRotation[2], 
			   c = 1,//clientFinalRotation[1], 
			   d = 1;//clientFinalRotation[0];

		mat[0] = 1 - 2*(pow(c,2) + pow(d,2));
		mat[1] = 2*(b*c + d*a);
		mat[2] = 2*(b*d - c*a);
		mat[3] = 0;

		mat[4] = 2*(b*c - d*a);
		mat[5] = 1 - 2*(pow(b,2) + pow(d,2));
		mat[6] = 2*(c*d + b*a);
		mat[7] = 0;

		mat[8] = 2*(b*d + c*a);
		mat[9] = 2*(c*d - b*a);
		mat[10] = 1 - 2*(pow(b,2) + pow(c,2));
		mat[11] = 0;

		mat[12] = clientFinalPosition[0];
		mat[13] = clientFinalPosition[1];
		mat[14] = clientFinalPosition[2];
		mat[15] = 1;
	}
}


void Tracker::lerp(double* final, double* start, double* end, double coef)
{
	if(final != NULL)
	{
		final[0] = start[0]*(1-coef) + end[0]*coef;
		final[1] = start[1]*(1-coef) + end[1]*coef;
		final[2] = start[2]*(1-coef) + end[2]*coef;
	}
}


